import type { Metadata, Viewport } from 'next'
import { Cormorant_Garamond, Geist_Mono } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const cormorantGaramond = Cormorant_Garamond({ 
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-serif"
})

const geistMono = Geist_Mono({ 
  subsets: ["latin"],
  variable: "--font-mono"
})

export const metadata: Metadata = {
  title: 'Morning with my Master',
  description: 'A 365 day devotional with the words of the Lord Jesus Christ. Start each day in the presence of your Savior.',
  generator: 'v0.app',
  manifest: '/manifest.json',
  keywords: ['devotional', 'Jesus', 'Christ', 'Bible', 'KJV', 'daily', 'scripture', 'faith'],
  authors: [{ name: 'Morning with my Master' }],
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
  openGraph: {
    title: 'Morning with my Master',
    description: 'A 365 day devotional with the words of the Lord Jesus Christ',
    type: 'website',
  },
}

export const viewport: Viewport = {
  themeColor: '#2c1810',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`${cormorantGaramond.variable} ${geistMono.variable} font-serif antialiased`}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
