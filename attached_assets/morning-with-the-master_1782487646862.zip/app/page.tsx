import { DevotionalClient } from "@/components/devotional-client";

export default function Home() {
  return <DevotionalClient />;
}
