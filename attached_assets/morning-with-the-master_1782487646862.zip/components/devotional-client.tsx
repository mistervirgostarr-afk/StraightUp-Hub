"use client";

import dynamic from "next/dynamic";

const DevotionalApp = dynamic(
  () => import("@/components/devotional-app").then((mod) => mod.DevotionalApp),
  {
    ssr: false,
    loading: () => (
      <div className="relative min-h-screen">
        <div 
          className="fixed inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: "url('/library-bg.jpg')" }}
        >
          <div className="absolute inset-0 bg-background/85" />
        </div>
        <div className="relative z-10 flex items-center justify-center min-h-screen">
          <div className="text-center">
            <h1 className="text-3xl md:text-4xl font-serif text-primary mb-4">
              Morning with my Master
            </h1>
            <div className="animate-pulse text-muted-foreground">Loading today&apos;s word...</div>
          </div>
        </div>
      </div>
    ),
  }
);

export function DevotionalClient() {
  return <DevotionalApp />;
}
